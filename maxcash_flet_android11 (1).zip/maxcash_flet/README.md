# MAXCASH (Flet) – Android 11+

Este proyecto contiene la app Flet con interfaz gráfica (pestañas, formularios, tablas) y configuración lista para compilar **APK/AAB** en Android 11+.

## Estructura
```
maxcash_flet/
├─ README.md
├─ pyproject.toml
└─ src/
   ├─ assets/
   │  └─ icon.png
   └─ main.py
```

## Requisitos
- Python 3.9+
- `pip install flet pandas openpyxl`

> El comando `flet build` instalará Flutter/JDK/Android SDK si faltan en el primer build.

## Compilar APK (Android 11+)
```bash
# Crear y activar venv (opcional)
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate

pip install --upgrade pip
pip install flet pandas openpyxl

# Compilar APK
flet build apk
# (opcional) reducir tamaño por arquitectura
flet build apk --split-per-abi
```

**Instalar en dispositivo**
```bash
adb install build/apk/app-release.apk
```

**Play Store** (recomendado):
```bash
flet build aab
```

## Icono
Reemplaza `src/assets/icon.png` con tu logo PNG (recomendado 1024×1024). Si modificas el icono, vuelve a compilar.

## Notas
- Si usas paquetes con extensiones nativas y el build falla, fija versiones con wheels Android compatibles en `pyproject.toml` o reduce dependencias.
