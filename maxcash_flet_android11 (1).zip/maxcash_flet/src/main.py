import os
import json
import unicodedata
from datetime import datetime, date
from typing import Optional, List

import flet as ft
import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.styles import Alignment

# ================= CONFIGURACIÓN PERSISTENTE =================
CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".maxcash_config.json")

DEFAULT_BASE_DIR = os.path.join(os.path.expanduser("~"), "Documents")
DEFAULT_COMISION_TOTAL = 10.0
DEFAULT_COMISION_IZIPAY = 3.0

CONFIG = {
    "base_dir": DEFAULT_BASE_DIR,
    "comision_total_def": DEFAULT_COMISION_TOTAL,
    "comision_izipay_def": DEFAULT_COMISION_IZIPAY,
}

def cargar_config():
    global CONFIG
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                for k in CONFIG.keys():
                    if k in data:
                        CONFIG[k] = data[k]
        if abs(CONFIG.get("comision_izipay_def", 3.0) - 2.23) < 1e-9:
            CONFIG["comision_izipay_def"] = 3.0
            guardar_config()
    except Exception:
        pass

def guardar_config():
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(CONFIG, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"No se pudo guardar la configuración: {e}")

# ================= RUTAS DINÁMICAS =================
def actualizar_rutas_desde_config():
    global BASE, CARPETA_MAXCASH, CARPETA_BACKUPS
    BASE = CONFIG.get("base_dir", DEFAULT_BASE_DIR)
    CARPETA_MAXCASH = os.path.join(BASE, "MAXCASH")
    CARPETA_BACKUPS = os.path.join(BASE, "MAXCASH-backups")

cargar_config()
actualizar_rutas_desde_config()

# ================= CONSTANTES =================
COLUMNAS = [
    "FechaHora", "Nombre", "DNI", "Telefono",
    "MontoBase", "ComisionTotalPct", "ComisionIzipayPct",
    "ComisionTotal", "ComisionIzipay",
    "GananciaNeta", "TotalCliente"
]

ARCHIVO_ACTIVO: Optional[str] = None

# ================= UTILIDADES =================
def crear_carpetas():
    os.makedirs(CARPETA_MAXCASH, exist_ok=True)
    os.makedirs(CARPETA_BACKUPS, exist_ok=True)

def listar_excels() -> List[str]:
    if not os.path.exists(CARPETA_MAXCASH):
        return []
    return sorted([f for f in os.listdir(CARPETA_MAXCASH) if f.lower().endswith(".xlsx")])

def _normalizar_decimales(txt):
    if isinstance(txt, str):
        txt = txt.strip().replace(",", ".")
    return txt

def _normalizar_texto_busqueda(s):
    if s is None:
        return ""
    if not isinstance(s, str):
        s = str(s)
    s = s.lower()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return s

# ------- I/O Excel segura --------
from openpyxl import load_workbook

def _intentar(accion_desc, func, *args, **kwargs):
    try:
        return func(*args, **kwargs)
    except PermissionError as e:
        raise RuntimeError(f"No se pudo {accion_desc}: {e}. Cierra el archivo en Excel y vuelve a intentar.") from e
    except OSError as e:
        msg = str(e).lower()
        if "permission denied" in msg or "used by another process" in msg or "cannot access the file" in msg:
            raise RuntimeError(f"No se pudo {accion_desc}: {e}. Cierra el archivo en Excel y vuelve a intentar.") from e
        else:
            raise

def _safe_to_excel(ruta, df, mode="w", sheet_name="Sheet1", if_sheet_exists=None):
    def _write():
        if mode == "w":
            with pd.ExcelWriter(ruta, engine="openpyxl", mode="w") as writer:
                df.to_excel(writer, sheet_name=sheet_name, index=False)
        else:
            if if_sheet_exists is not None:
                with pd.ExcelWriter(ruta, engine="openpyxl", mode="a", if_sheet_exists=if_sheet_exists) as writer:
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
            else:
                with pd.ExcelWriter(ruta, engine="openpyxl", mode="a") as writer:
                    df.to_excel(writer, sheet_name=sheet_name, index=False)
    _intentar("escribir en Excel", _write)

def _safe_load_workbook(ruta):
    return _intentar("abrir el Excel", load_workbook, ruta)

def _safe_wb_save(wb, ruta):
    _intentar("guardar cambios en Excel", wb.save, ruta)

# ------- Excel helpers --------

def crear_excel(nombre):
    import pandas as pd
    ruta = os.path.join(CARPETA_MAXCASH, nombre + ".xlsx")
    if not os.path.exists(ruta):
        df = pd.DataFrame(columns=COLUMNAS)
        df = df.astype({
            "Nombre": "string",
            "DNI": "string",
            "Telefono": "string",
            "MontoBase": "float64",
            "ComisionTotalPct": "float64",
            "ComisionIzipayPct": "float64",
            "ComisionTotal": "float64",
            "ComisionIzipay": "float64",
            "GananciaNeta": "float64",
            "TotalCliente": "float64"
        })
        guardar_df(df, ruta)
    return ruta

def cargar_df(ruta):
    import pandas as pd
    if not os.path.exists(ruta):
        return pd.DataFrame(columns=COLUMNAS)

    df = pd.read_excel(
        ruta,
        engine="openpyxl",
        dtype={"DNI": str, "Telefono": str, "Nombre": str},
    )

    for c in COLUMNAS:
        if c not in df.columns:
            df[c] = "" if c in ["Nombre", "DNI", "Telefono"] else 0

    if "FechaHora" in df.columns:
        df["FechaHora"] = pd.to_datetime(df["FechaHora"], errors="coerce")

    for c in ["MontoBase","ComisionTotalPct","ComisionIzipayPct",
              "ComisionTotal","ComisionIzipay","GananciaNeta","TotalCliente"]:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)

    for c in ["Nombre","DNI","Telefono"]:
        df[c] = df[c].astype("string").fillna("")

    return df


def _display_text_for_width(col_name, value):
    if value is None:
        return ""
    if col_name in ["MontoBase","ComisionTotal","ComisionIzipay","GananciaNeta","TotalCliente"]:
        try:
            x = float(value)
            return f"S/ {x:,.2f}"
        except:
            return str(value)
    if col_name in ["ComisionTotalPct","ComisionIzipayPct"]:
        try:
            x = float(value)
            return f"{x:.2f}"
        except:
            return str(value)
    if col_name == "FechaHora":
        try:
            import pandas as pd
            return pd.to_datetime(value).strftime("%d/%m/%Y %H:%M")
        except:
            return str(value)
    return str(value)


def _aplicar_formato_hoja(ws):
    for cell in ws["A"][1:]:
        cell.number_format = "DD/MM/YYYY HH:mm"

    for col in ["C", "D"]:
        for cell in ws[col][1:]:
            cell.number_format = "@"
            cell.alignment = Alignment(horizontal="left")

    for col in ["E", "H", "I", "J", "K"]:
        for cell in ws[col][1:]:
            cell.number_format = '"S/ "#,##0.00'
            cell.alignment = Alignment(horizontal="right")

    for col in ["F", "G"]:
        for cell in ws[col][1:]:
            cell.alignment = Alignment(horizontal="right")

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    headers = [ws.cell(row=1, column=i).value for i in range(1, ws.max_column + 1)]
    max_width = 60
    min_width_by_colletter = {"E": 14, "H": 14, "I": 14, "J": 14, "K": 14}

    for col_idx in range(1, ws.max_column + 1):
        col_letter = get_column_letter(col_idx)
        header = headers[col_idx-1] or ""
        col_name = str(header)
        max_len = len(str(header))
        for row_idx in range(2, ws.max_row + 1):
            v = ws.cell(row=row_idx, column=col_idx).value
            s = _display_text_for_width(col_name, v)
            if len(s) > max_len:
                max_len = len(s)
        width = min(max_len + 2, max_width)
        if col_letter in min_width_by_colletter:
            width = max(width, min_width_by_colletter[col_letter])
        ws.column_dimensions[col_letter].width = width

    max_row = ws.max_row
    max_col = ws.max_column
    if max_row >= 2 and max_col >= 1:
        ref = f"A1:{get_column_letter(max_col)}{max_row}"
        if ws._tables:
            for t in list(ws._tables):
                ws._tables.remove(t)
        table = Table(displayName="TablaMAXCASH", ref=ref)
        style = TableStyleInfo(
            name="TableStyleMedium9", showFirstColumn=False,
            showLastColumn=False, showRowStripes=True, showColumnStripes=False
        )
        table.tableStyleInfo = style
        ws.add_table(table)


def _fmt_text(v):
    if v is None:
        return ""
    return str(v)


def _fmt_fecha(v):
    import pandas as pd
    if pd.isna(v):
        return ""
    try:
        return pd.to_datetime(v).strftime("%d/%m/%Y %H:%M:%S")
    except Exception:
        return _fmt_text(v)


def _fmt_currency(v):
    try:
        x = float(v)
        return f"S/ {x:,.2f}"
    except Exception:
        return ""


def _fmt_percent(v):
    try:
        x = float(v)
        return f"{x:.2f}%"
    except Exception:
        return ""


def _formatear_tabla_log(df: pd.DataFrame) -> str:
    cols = [c for c in COLUMNAS if c in df.columns]
    formatters = {
        "FechaHora": _fmt_fecha,
        "Nombre": _fmt_text,
        "DNI": _fmt_text,
        "Telefono": _fmt_text,
        "MontoBase": _fmt_currency,
        "ComisionTotalPct": _fmt_percent,
        "ComisionIzipayPct": _fmt_percent,
        "ComisionTotal": _fmt_currency,
        "ComisionIzipay": _fmt_currency,
        "GananciaNeta": _fmt_currency,
        "TotalCliente": _fmt_currency
    }
    col_values = {c: [] for c in cols}
    for _, row in df.iterrows():
        for c in cols:
            val = row[c] if c in row else ""
            col_values[c].append(formatters.get(c, _fmt_text)(val))

    widths = {c: max(len(c), *(len(s) for s in col_values[c])) for c in cols}

    header_line = " | ".join(c.ljust(widths[c]) for c in cols)
    sep_line = "-+-".join("-" * widths[c] for c in cols)
    right_align = {
        "MontoBase","ComisionTotalPct","ComisionIzipayPct",
        "ComisionTotal","ComisionIzipay","GananciaNeta","TotalCliente"
    }

    lines = [header_line, sep_line]
    n = len(df)
    for i in range(n):
        parts = []
        for c in cols:
            s = col_values[c][i]
            parts.append(s.rjust(widths[c]) if c in right_align else s.ljust(widths[c]))
        lines.append(" | ".join(parts))
    return "
".join(lines)


def _escribir_log_para_excel(ruta_excel, df):
    os.makedirs(CARPETA_BACKUPS, exist_ok=True)
    base_name = os.path.splitext(os.path.basename(ruta_excel))[0]
    log_path = os.path.join(CARPETA_BACKUPS, f"log_{base_name}.txt")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    def _append():
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("
" + "="*80 + "
")
            f.write(f"LOG DE: {base_name} | Fecha/Hora: {timestamp}
")
            f.write("="*80 + "
")
            f.write(f"Filas: {len(df)} | Columnas: {len(df.columns)}

")
            df_print = df.copy()
            for c in COLUMNAS:
                if c not in df_print.columns:
                    df_print[c] = "" if c in ["Nombre", "DNI", "Telefono"] else 0
            tabla = _formatear_tabla_log(df_print[COLUMNAS])
            f.write(tabla)
            f.write("
")
    _intentar("escribir el log", _append)


def guardar_df(df, ruta):
    os.makedirs(CARPETA_MAXCASH, exist_ok=True)
    os.makedirs(CARPETA_BACKUPS, exist_ok=True)

    if "FechaHora" in df.columns:
        df["FechaHora"] = pd.to_datetime(df["FechaHora"], errors="coerce")

    _safe_to_excel(ruta, df, mode="w", sheet_name="Sheet1")

    wb = _safe_load_workbook(ruta)
    ws = wb.active
    _aplicar_formato_hoja(ws)
    _safe_wb_save(wb, ruta)

    _escribir_log_para_excel(ruta, df)


def _unique_sheet_name(ruta_excel: str, desired: str) -> str:
    wb = _safe_load_workbook(ruta_excel)
    names = set(wb.sheetnames)
    if desired not in names:
        return desired
    i = 2
    while True:
        candidate = f"{desired} ({i})"
        if candidate not in names:
            return candidate
        i += 1


def escribir_hoja_resumen(ruta_excel, nombre_hoja_deseado, df_resumen, columnas_moneda=None, columnas_fecha=None):
    nombre_hoja = _unique_sheet_name(ruta_excel, nombre_hoja_deseado)
    _safe_to_excel(ruta_excel, df_resumen, mode="a", sheet_name=nombre_hoja)

    wb = _safe_load_workbook(ruta_excel)
    ws = wb[nombre_hoja]
    headers = {ws.cell(row=1, column=i).value: get_column_letter(i) for i in range(1, ws.max_column + 1)}

    if columnas_moneda:
        for col_name in columnas_moneda:
            col_letter = headers.get(col_name)
            if col_letter:
                for cell in ws[col_letter][1:]:
                    cell.number_format = '"S/ "#,##0.00'
                    cell.alignment = Alignment(horizontal="right")

    if columnas_fecha:
        for col_name in columnas_fecha:
            col_letter = headers.get(col_name)
            if col_letter:
                for cell in ws[col_letter][1:]:
                    cell.number_format = "DD/MM/YYYY"

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    max_width = 60
    for col_idx in range(1, ws.max_column + 1):
        col_letter = get_column_letter(col_idx)
        header = ws.cell(row=1, column=col_idx).value or ""
        col_name = str(header)
        max_len = len(str(header))
        for row_idx in range(2, ws.max_row + 1):
            v = ws.cell(row=row_idx, column=col_idx).value
            s = _display_text_for_width(col_name, v)
            if len(s) > max_len:
                max_len = len(s)
        width = min(max_len + 2, max_width)
        ws.column_dimensions[col_letter].width = width

    max_row = ws.max_row
    max_col = ws.max_column
    if max_row >= 2:
        ref = f"A1:{get_column_letter(max_col)}{max_row}"
        table = Table(displayName=f"Tabla_{nombre_hoja.replace(' ', '_')[:28]}", ref=ref)
        style = TableStyleInfo(
            name="TableStyleMedium9", showFirstColumn=False,
            showLastColumn=False, showRowStripes=True, showColumnStripes=False
        )
        table.tableStyleInfo = style
        ws.add_table(table)

    _safe_wb_save(wb, ruta_excel)
    return nombre_hoja

# ================= UI (Flet) =================

def df_to_datatable(df: pd.DataFrame) -> ft.DataTable:
    cols = [ft.DataColumn(ft.Text(str(c))) for c in df.columns]
    rows = []
    for _, r in df.iterrows():
        cells = []
        for c in df.columns:
            v = r[c]
            if c in ["MontoBase","ComisionTotal","ComisionIzipay","GananciaNeta","TotalCliente"]:
                try:
                    cells.append(ft.DataCell(ft.Text(f"S/ {float(v):,.2f}")))
                except:
                    cells.append(ft.DataCell(ft.Text(str(v))))
            elif c in ["ComisionTotalPct","ComisionIzipayPct"]:
                try:
                    cells.append(ft.DataCell(ft.Text(f"{float(v):.2f}%")))
                except:
                    cells.append(ft.DataCell(ft.Text(str(v))))
            elif c in ["FechaHora","Fecha","Mes"]:
                try:
                    if c == "Mes" and isinstance(v, str):
                        cells.append(ft.DataCell(ft.Text(v)))
                    else:
                        cells.append(ft.DataCell(ft.Text(pd.to_datetime(v).strftime("%d/%m/%Y %H:%M") if c=="FechaHora" else pd.to_datetime(v).strftime("%d/%m/%Y"))))
                except:
                    cells.append(ft.DataCell(ft.Text(str(v))))
            else:
                cells.append(ft.DataCell(ft.Text("" if pd.isna(v) else str(v))))
        rows.append(ft.DataRow(cells=cells))
    return ft.DataTable(columns=cols, rows=rows, column_spacing=12, data_row_min_height=36)


def main(page: ft.Page):
    page.title = "MAXCASH (Flet)"
    page.horizontal_alignment = ft.CrossAxisAlignment.STRETCH
    page.scroll = ft.ScrollMode.AUTO
    page.window_min_width = 980
    page.window_min_height = 680
    page.theme = ft.Theme(color_scheme_seed="#0B1F3B", use_material3=True)

    crear_carpetas()
    excels = listar_excels()
    global ARCHIVO_ACTIVO
    ARCHIVO_ACTIVO = crear_excel("MAXCASH_1") if not excels else os.path.join(CARPETA_MAXCASH, excels[0])

    def refresh_excels():
        return listar_excels()

    def set_active_excel_by_name(name: str):
        nonlocal excels_title
        global ARCHIVO_ACTIVO
        ARCHIVO_ACTIVO = os.path.join(CARPETA_MAXCASH, name)
        excels_title.value = f"Excel activo: {os.path.basename(ARCHIVO_ACTIVO)}"
        page.update()

    def notify(msg: str, success: bool = True):
        page.snack_bar = ft.SnackBar(ft.Text(msg), bgcolor=("#2e7d32" if success else "#c62828"))
        page.snack_bar.open = True
        page.update()

    def handle_excel_open_error(e: Exception):
        notify(str(e), success=False)

    excels_title = ft.Text(f"Excel activo: {os.path.basename(ARCHIVO_ACTIVO)}", size=14, weight=ft.FontWeight.W600)
    path_title = ft.Text(f"Ruta: {os.path.join(BASE, 'MAXCASH')}", size=12, color=ft.colors.GREY)
    page.appbar = ft.AppBar(
        title=ft.Column([ft.Text("MAXCASH", size=20, weight=ft.FontWeight.BOLD), excels_title, path_title], spacing=0),
        center_title=False,
        bgcolor=ft.colors.SURFACE_VARIANT
    )

    (ct_def, ci_def) = (CONFIG.get("comision_total_def", 10.0), CONFIG.get("comision_izipay_def", 3.0))
    nombre_tf = ft.TextField(label="Nombre", autofocus=True)
    dni_tf = ft.TextField(label="DNI (8 dígitos, opcional)", max_length=8)
    tel_tf = ft.TextField(label="Teléfono (9 dígitos, opcional)", max_length=9)
    monto_tf = ft.TextField(label="Monto (lo que el cliente QUIERE)", keyboard_type=ft.KeyboardType.NUMBER)
    ct_tf = ft.TextField(label=f"Comisión total % (por defecto {ct_def})", value=str(ct_def), keyboard_type=ft.KeyboardType.NUMBER)
    ci_tf = ft.TextField(label=f"Comisión Izipay % (por defecto {ci_def})", value=str(ci_def), keyboard_type=ft.KeyboardType.NUMBER)
    modo_dd = ft.Dropdown(label="Modo de cobro", hint_text="Elige el modo",
        options=[ft.dropdown.Option("SUMAR ENCIMA"), ft.dropdown.Option("INCLUIR EN EL MONTO")], value="SUMAR ENCIMA")
    chk_guardar_def = ft.Checkbox(label="Guardar estos % como nuevos predeterminados", value=False)

    def validar_registro() -> Optional[str]:
        dni = dni_tf.value.strip()
        tel = tel_tf.value.strip()
        if dni and not (dni.isdigit() and len(dni) == 8):
            return "DNI inválido (debe tener 8 dígitos)."
        if tel and not (tel.isdigit() and len(tel) == 9):
            return "Teléfono inválido (debe tener 9 dígitos)."
        try:
            monto = float(_normalizar_decimales(monto_tf.value))
            if monto <= 0:
                return "Monto inválido (debe ser > 0)."
        except:
            return "Monto inválido."
        try:
            ct = float(_normalizar_decimales(ct_tf.value))
            ci = float(_normalizar_decimales(ci_tf.value))
            if not (0 <= ct <= 100 and 0 <= ci <= 100):
                return "Comisiones inválidas (0–100)."
        except:
            return "Comisiones inválidas."
        return None

    def registrar_tramite_ui(e=None):
        if not ARCHIVO_ACTIVO:
            notify("No hay Excel activo.", success=False)
            return
        err = validar_registro()
        if err:
            notify(err, success=False)
            return
        try:
            nombre = (nombre_tf.value or "").strip()
            dni = (dni_tf.value or "").strip()
            telefono = (tel_tf.value or "").strip()
            monto_ingresado = float(_normalizar_decimales(monto_tf.value))
            ct = float(_normalizar_decimales(ct_tf.value))
            ci = float(_normalizar_decimales(ci_tf.value))
            modo = modo_dd.value or "SUMAR ENCIMA"

            if modo == "SUMAR ENCIMA":
                base = monto_ingresado
                com_total = base * ct / 100.0
                total_cliente = base + com_total
                izipay = base * ci / 100.0
            else:
                total_cliente = monto_ingresado
                com_total = total_cliente * ct / 100.0
                izipay = total_cliente * ci / 100.0
                base = total_cliente - com_total

            ganancia = com_total - izipay

            data = {
                "FechaHora": datetime.now(),
                "Nombre": nombre,
                "DNI": dni,
                "Telefono": telefono,
                "MontoBase": round(base, 2),
                "ComisionTotalPct": ct,
                "ComisionIzipayPct": ci,
                "ComisionTotal": round(com_total, 2),
                "ComisionIzipay": round(izipay, 2),
                "GananciaNeta": round(ganancia, 2),
                "TotalCliente": round(total_cliente, 2)
            }

            df = cargar_df(ARCHIVO_ACTIVO)
            df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
            guardar_df(df, ARCHIVO_ACTIVO)

            if chk_guardar_def.value:
                CONFIG["comision_total_def"] = ct
                CONFIG["comision_izipay_def"] = ci
                guardar_config()

            notify(f"Trámite registrado. Ganancia: S/ {ganancia:.2f} | Total cliente: S/ {total_cliente:.2f}")
            monto_tf.value = ""
            page.update()
        except Exception as ex:
            handle_excel_open_error(ex)

    btn_registrar = ft.ElevatedButton("Registrar trámite", icon=ft.icons.SAVE, on_click=registrar_tramite_ui)

    registro_tab = ft.Container(
        content=ft.Column([
            ft.Text("Registrar trámite", size=18, weight=ft.FontWeight.BOLD),
            ft.ResponsiveRow([
                ft.Container(nombre_tf, col={"xs":12, "sm":6, "md":4}),
                ft.Container(dni_tf, col={"xs":12, "sm":6, "md":4}),
                ft.Container(tel_tf, col={"xs":12, "sm":6, "md":4}),
                ft.Container(monto_tf, col={"xs":12, "sm":6, "md":4}),
                ft.Container(ct_tf, col={"xs":12, "sm":6, "md":4}),
                ft.Container(ci_tf, col={"xs":12, "sm":6, "md":4}),
                ft.Container(modo_dd, col={"xs":12, "sm":6, "md":4}),
                ft.Container(chk_guardar_def, col={"xs":12, "sm":12, "md":6}),
            ], run_spacing=10, spacing=10),
            btn_registrar
        ], spacing=16),
        padding=20
    )

    # ===== Reportes (resumen) =====
    def calcular_ganancia_global():
        total = 0.0
        for e_ in refresh_excels():
            df = cargar_df(os.path.join(CARPETA_MAXCASH, e_))
            total += df["GananciaNeta"].sum()
        return total

    def calcular_izipay_global():
        total = 0.0
        for e_ in refresh_excels():
            df = cargar_df(os.path.join(CARPETA_MAXCASH, e_))
            total += df["ComisionIzipay"].sum()
        return total

    lbl_g_global = ft.Text("")
    lbl_i_global = ft.Text("")

    def refresh_globales(e=None):
        try:
            gg = calcular_ganancia_global()
            ii = calcular_izipay_global()
            lbl_g_global.value = f"Ganancia global: S/ {gg:,.2f}"
            lbl_i_global.value = f"Izipay global: S/ {ii:,.2f}"
            page.update()
        except Exception as ex:
            handle_excel_open_error(ex)

    refresh_globales()

    reportes_tab = ft.Container(
        content=ft.Column([
            ft.Text("Ganancias / Reportes", size=18, weight=ft.FontWeight.BOLD),
            ft.Row([
                ft.Icon(ft.icons.ACCOUNT_BALANCE_WALLET), lbl_g_global,
                ft.Container(width=24),
                ft.Icon(ft.icons.CREDIT_CARD), lbl_i_global,
                ft.Container(width=16),
                ft.OutlinedButton("Actualizar totales", icon=ft.icons.REFRESH, on_click=refresh_globales),
            ], alignment=ft.MainAxisAlignment.START),
        ], spacing=14),
        padding=20
    )

    # ===== Búsqueda =====
    tf_query = ft.TextField(label="Texto a buscar", expand=True)
    res_busqueda = ft.Column([])

    def buscar_click(e=None):
        texto = _normalizar_texto_busqueda(tf_query.value or "")
        if not texto:
            notify("Ingresa un texto a buscar.", success=False)
            return
        def buscar(df):
            def row_to_text(r):
                return _normalizar_texto_busqueda(" ".join("" if x is None else str(x) for x in r.values))
            mask = df.apply(lambda r: texto in row_to_text(r), axis=1)
            return df[mask]
        res_busqueda.controls = []
        hubo = False
        try:
            for e_ in refresh_excels():
                ruta = os.path.join(CARPETA_MAXCASH, e_)
                df = cargar_df(ruta)
                res = buscar(df)
                if not res.empty:
                    hubo = True
                    res_busqueda.controls.append(ft.Text(f"📁 {e_}", weight=ft.FontWeight.W600))
                    res_busqueda.controls.append(df_to_datatable(res))
            if not hubo:
                res_busqueda.controls.append(ft.Text("🔎 Sin coincidencias.", color=ft.colors.GREY))
            page.update()
        except Exception as ex:
            handle_excel_open_error(ex)

    btn_buscar = ft.ElevatedButton("Buscar", icon=ft.icons.SEARCH, on_click=buscar_click)

    busqueda_tab = ft.Container(
        content=ft.Column([
            ft.Text("Búsqueda", size=18, weight=ft.FontWeight.BOLD),
            ft.Row([tf_query, btn_buscar]),
            res_busqueda
        ], spacing=12),
        padding=20
    )

    # ===== Excel (gestión) =====
    dd_excels_manage = ft.Dropdown(label="Selecciona Excel", options=[ft.dropdown.Option(e) for e in refresh_excels()], value=os.path.basename(ARCHIVO_ACTIVO))

    def set_activo_click(e=None):
        if dd_excels_manage.value:
            set_active_excel_by_name(dd_excels_manage.value)
            notify(f"Excel activo: {dd_excels_manage.value}")

    def crear_excel_click(e=None):
        try:
            nombre = "MAXCASH_" + datetime.now().strftime("%Y%m%d_%H%M%S")
            ruta = crear_excel(nombre)
            dd_excels_manage.options = [ft.dropdown.Option(x) for x in refresh_excels()]
            dd_excels_manage.value = os.path.basename(ruta)
            set_active_excel_by_name(dd_excels_manage.value)
            notify(f"Creado y activo: {dd_excels_manage.value}")
        except Exception as ex:
            handle_excel_open_error(ex)

    excel_tab = ft.Container(
        content=ft.Column([
            ft.Text("Gestionar Excel", size=18, weight=ft.FontWeight.BOLD),
            dd_excels_manage,
            ft.Row([
                ft.ElevatedButton("Establecer como activo", icon=ft.icons.CHECK_CIRCLE, on_click=set_activo_click),
                ft.Container(width=24),
                ft.ElevatedButton("Crear nuevo Excel", icon=ft.icons.ADD, on_click=crear_excel_click),
            ])
        ], spacing=12),
        padding=20
    )

    # ===== Configuración =====
    base_dir_tf = ft.TextField(label="Ruta base", value=os.path.join(BASE, 'MAXCASH'), expand=True, read_only=True)

    def cambiar_ruta_click(e=None):
        notify("Para Android, la ruta base se guarda en configuración local.")

    ct_def_tf = ft.TextField(label="Comisión total % (defecto)", value=str(CONFIG.get("comision_total_def", 10.0)), width=220)
    ci_def_tf = ft.TextField(label="Comisión Izipay % (defecto)", value=str(CONFIG.get("comision_izipay_def", 3.0)), width=220)

    def guardar_config_click(e=None):
        try:
            ct = float(_normalizar_decimales(ct_def_tf.value))
            ci = float(_normalizar_decimales(ci_def_tf.value))
            if not (0 <= ct <= 100 and 0 <= ci <= 100):
                notify("Valores inválidos de % por defecto.", success=False)
                return
            CONFIG["comision_total_def"] = ct
            CONFIG["comision_izipay_def"] = ci
            guardar_config()
            notify("Configuración guardada.")
        except Exception:
            notify("Valores inválidos de % por defecto.", success=False)

    config_tab = ft.Container(
        content=ft.Column([
            ft.Text("Configuración", size=18, weight=ft.FontWeight.BOLD),
            ft.Row([base_dir_tf, ft.OutlinedButton("Cambiar carpeta base…", icon=ft.icons.FOLDER_OPEN, on_click=cambiar_ruta_click)]),
            ft.Divider(),
            ft.Text("Predeterminados de comisión", weight=ft.FontWeight.W600),
            ft.Row([ct_def_tf, ci_def_tf, ft.ElevatedButton("Guardar", icon=ft.icons.SAVE, on_click=guardar_config_click)]),
        ], spacing=12),
        padding=20
    )

    tabs = ft.Tabs(
        selected_index=0,
        tabs=[
            ft.Tab(text="Registro", icon=ft.icons.ADD, content=registro_tab),
            ft.Tab(text="Reportes", icon=ft.icons.ANALYTICS, content=reportes_tab),
            ft.Tab(text="Búsqueda", icon=ft.icons.SEARCH, content=busqueda_tab),
            ft.Tab(text="Excel", icon=ft.icons.DESCRIPTION, content=excel_tab),
            ft.Tab(text="Configuración", icon=ft.icons.SETTINGS, content=config_tab),
        ],
        expand=1
    )

    page.add(tabs)

if __name__ == "__main__":
    ft.app(target=main)
